using System.ComponentModel.DataAnnotations;

namespace hihi.Models
{
    public class Dane
    {
        [Required(ErrorMessage = "Imię jest wymagane")]
        [MinLength(2, ErrorMessage = "Imię musi mieć co najmniej 2 znaki")]
        public string? Imie { get; set; }

        [Required(ErrorMessage = "Nazwisko jest wymagane")]
        [MinLength(2, ErrorMessage = "Nazwisko musi mieć co najmniej 2 znaki")]
        public string? Nazwisko { get; set; }

        [Required(ErrorMessage = "Adres e-mail jest wymagany")]
        [EmailAddress(ErrorMessage = "Niepoprawny format adresu e-mail")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Hasło jest wymagane")]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$", ErrorMessage = "Hasło musi zawierać co najmniej 8 znaków, w tym jedną dużą literę, jedną małą literę i jedną cyfrę")]
        public string? Haslo { get; set; }

        [Required(ErrorMessage = "Potwierdzenie hasła jest wymagane")]
        [Compare("Haslo", ErrorMessage = "Hasła nie są zgodne")]
        public string? PotwierdzenieHasla { get; set; }

        [Required(ErrorMessage = "Numer telefonu jest wymagany")]
        [Phone(ErrorMessage = "Niepoprawny numer telefonu")]
        public string? NrTelefonu { get; set; }

        [Required(ErrorMessage = "Wiek jest wymagany")]
        [Range(10, 80, ErrorMessage = "Wiek musi być pomiędzy 10 a 80 lat")]
        public int Wiek { get; set; }

        [Required(ErrorMessage = "Miasto jest wymagane")]
        public string? Miasto { get; set; }
    }
}

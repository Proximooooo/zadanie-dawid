using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Collections.Generic;

namespace hihi.Pages
{
    public class DaneModel : PageModel
    {
        // Publiczna statyczna lista do przechowywania wprowadzonych danych
        public static List<Dane> WprowadzoneDane { get; set; } = new List<Dane>();

        public void OnGet()
        {
            // Ta metoda może pozostać pusta, dane są dynamicznie wyświetlane w widoku
        }

        // Metoda do dodawania danych do listy
        public static void DodajDane(Dane dane)
        {
            WprowadzoneDane.Add(dane);
        }
    }
}

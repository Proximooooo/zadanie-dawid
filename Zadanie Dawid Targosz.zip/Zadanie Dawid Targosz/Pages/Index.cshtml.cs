using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;

namespace hihi.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Dane Dane { get; set; } = new Dane();

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                // Dodanie danych do statycznej listy w klasie DaneModel
                DaneModel.DodajDane(Dane);

                TempData["Sukces"] = "Formularz został pomyślnie przesłany!";
                return RedirectToPage(); // Odświeżenie strony po przesłaniu
            }

            return Page();
        }
    }
}
